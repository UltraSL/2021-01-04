import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-advertistment',
  templateUrl: './advertistment.component.html',
  styleUrls: ['./advertistment.component.css']
})
export class AdvertistmentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
