export class Pastpaper {


  _id: string;
  name:string;
  paperPath:string
}
