export class Video {
  _id: string;
  name:string;
  videoPath:string
}
