import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-update-post',
  templateUrl: './update-post.component.html',
  styleUrls: ['./update-post.component.css']
})
export class UpdatePostComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
