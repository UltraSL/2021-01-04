import { Component, OnInit,OnDestroy } from '@angular/core';
import { VideoService } from 'src/app/services/video.service'
import { Upload } from 'src/app/models/upload';
import { Subscription } from "rxjs";
@Component({
  selector: 'app-video-page',
  templateUrl: './video-page.component.html',
  styleUrls: ['./video-page.component.css']
})
export class VideoPageComponent implements OnInit ,OnDestroy {

  uploads: Upload[] = [];
  private profileSubscription: Subscription;

  constructor(private VideoService: VideoService) {}

  ngOnInit(): void {


    this.VideoService.getupload();
    this.profileSubscription = this.VideoService
      .getUploadStream()
      .subscribe((uploads: Upload[]) => {
        this.uploads = uploads;
      });
  }

  ngOnDestroy() {
    this.profileSubscription.unsubscribe();
  }


}

