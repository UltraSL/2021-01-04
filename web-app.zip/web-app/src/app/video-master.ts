export class VideoMaster
{
     int:number;
     Videos:string;
} 
