export interface Upload {
  _id: string;
  name: string;
  videoPath: string;
}
